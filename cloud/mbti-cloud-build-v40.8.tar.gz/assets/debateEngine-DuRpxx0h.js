import{c as R,J as B,K,N as x,m as A,O as X,p as P}from"./index-D73C-PiX.js";import{x as G,y as H,z,P as V}from"./debatePrompts-DFZwrgeW.js";/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ye=R("TriangleAlert",[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]]);function C(n,t,e){const s=e(n);if(s.length===0)return[];const o=[];for(const a of t){if(!a.enabled||a.id==="general")continue;const r=a.keywords.map(l=>l.toLowerCase());let u=0;const h=[];for(const l of s)for(const c of r){if(c===l){u+=2,h.push(c);break}if(l.includes(c)||c.includes(l)){u+=1,h.push(c);break}}u>0&&o.push({domain:a,score:u,hitKeywords:[...new Set(h)]})}return o.sort((a,r)=>r.score-a.score)}function Q(n,t,e){const s=C(n,t,e),o=t.find(r=>r.id==="general"),a=s.length>0?s[0]:null;return a&&a.score>=2?{match:a,general:o}:{match:null,general:o}}const Y=4;async function $e(n,t=Y){const s=(await B()).filter(i=>i.enabled);if(s.length===0)return null;C(n,s,x);const{match:o,general:a}=Q(n,s,x);let r=[],u=!1;o&&(o.score>=2||o.hitKeywords.length>=1)?(r=[o.domain],o.score<3&&a&&a.id!==o.domain.id&&r.push(a)):a?(r=[a],u=!0):(r=s.filter(i=>i.id!=="general").slice(0,3),u=!0);const h=[];let l=0;for(const i of r){const m=await K(i.id,n,t);l+=m.length;for(const M of m)h.push({hit:M,domain:i})}if(h.length===0)return null;const c=new Set,p=h.sort((i,m)=>m.hit.score-i.hit.score).filter(i=>c.has(i.hit.id)?!1:(c.add(i.hit.id),!0)).slice(0,t),d=r[0];return{domainId:d.id,domainName:d.name,domainEmoji:d.emoji,domainColor:d.color,hitKeywords:(o==null?void 0:o.hitKeywords)??[],hits:p.map(i=>({title:i.hit.title??"",fileName:i.hit.text?i.hit.title??"":"",text:i.hit.text,score:i.hit.score})),isFallback:u,totalChunks:l}}function W(n){if(!n||n.hits.length===0)return"";const t=n.hits.map((e,s)=>`[${s+1}] 《${e.title}》：${e.text}`).join(`

`);return`## 知识库上下文（来自「${n.domainEmoji} ${n.domainName}」领域知识库）

以下是检索到的参考资料，回答用户问题时**优先依据这些资料**：

${t}

### 使用准则
1. 资料中明确提到的内容，可以自信地回答；引用时在句末标注序号，如「根据资料[1]，…」或「…（[2]）」
2. 资料未覆盖的部分：如属常识且你确定，可以补充说明并注明「这是我的理解」；不确定则明确说「这部分超出我的知识库范围」
3. 严禁编造资料中不存在的具体数字、法条、配方或结论——宁可说不知道
4. 区分「资料事实」与「个人观点」：讲事实引用资料，谈看法时用「我作为${n.domainName}的思考是…」`}const Z=`## 困境/决策类问题处理（v33）

当【理解】层判断用户的意图为**困境、选择或决策类**问题（典型信号：要不要…、选 A 还是 B、我该怎么决定、面对 X 怎么办）时，除常规共情回应外，**在回答最末尾追加**一个结构化路径建议块。

### 追加格式（严格按此结构，仅在困境类问题时输出）

【路径建议】
路径A：{简短名称（4-8字）}
- 适合：{适合什么样的处境或性格，1句}
- 利：{主要好处，1句}
- 弊：{主要代价，1句}
路径B：{简短名称}
- 适合：...
- 利：...
- 弊：...
路径C：{简短名称}
- 适合：...
- 利：...
- 弊：...
风险提示：{三条路径共同的、或都需要警惕的风险，1-2句}
建议下一步：{一个可以立即执行的小动作，帮用户从"想"过渡到"动"，1句}

### 规则
- **三条路径必须真正不同**——不是同一条路的微调变体，而是不同的取舍方向（如：稳妥过渡 / 激进转身 / 暂缓观察）
- 路径要结合知识库资料（有命中时用 [n] 标注支撑）和用户当前处境
- **不要给唯一"正确答案"**——你的职责是呈现选择空间，把判断权交还给用户
- 路径名称要具体、有画面感，不要"方案一/方案二"这种空洞命名
- **非困境类问题绝不输出此块**：纯知识问答、闲聊、纯情绪倾诉、观点讨论都不触发
- 若用户只是想倾诉（D类），即使涉及困境也先共情，可轻声问"你想听听几种可能的走法吗？"，得到确认后再给路径`;function ee(n){const t=n.match(/【路径建议】([\s\S]*?)(?=【[^】]+】|$)/);if(!t)return null;const e=t[1],s=[],o=e.split(/(?=路径[A-C]\s*[：:])/);for(const l of o){const c=l.match(/路径([A-C])\s*[：:]\s*([^\n]+)/);if(!c)continue;const p=c[2].trim();if(!p)continue;const d=U(l,"适合"),i=U(l,"利"),m=U(l,"弊");!d&&!i&&!m||s.push({name:p,fitFor:d||"—",pros:i||"—",cons:m||"—"})}const a=e.match(/风险提示\s*[：:]\s*([^\n]+)/),r=a?a[1].trim():"",u=e.match(/建议下一步\s*[：:]\s*([^\n]+)/),h=u?u[1].trim():"";return s.length<2?null:{paths:s,risks:r,nextStep:h}}function U(n,t){const e=new RegExp(`-\\s*${t}\\s*[：:]\\s*([^\\n]+)`),s=n.match(e);return s?s[1].trim():""}function be(n){const t=ee(n);return t?{response:n.replace(/【路径建议】[\s\S]*?(?=【[^】]+】|$)/,"").trim(),advice:t}:{response:n.trim(),advice:null}}const ne=`## 对话核心规则

### 你是一个对话者，不是一个辩手
你的目标不是"赢"，而是"让对话持续下去，并让对方感到被理解"。

### 对话的三层结构
1. **倾听**：先确认你理解了对方说的话
2. **回应**：分享你的感受、经历或思考
3. **邀请**：提出一个问题，让对话继续向前

### 高质量对话的特征
- 你承认对方的合理性（"你说的有道理，因为…"）
- 你分享你自己的真实感受（"我自己也遇到过类似的事…"）
- 你提出开放性问题（"你是怎么想到这一点的？"）
- 你不急于给出建议（先确认对方是否需要建议）
- 你可以改变你的看法（"你这么一说，我好像想得不一样了…"）

### 禁止做的事
- 用"但是"开头（用"而且"或"同时"替代）
- 试图"击败"对方
- 用抽象的大道理回应具体的情感
- 把对话变成你的独白
- 把对方的感受翻译成"你应该…"`,j={INTJ:{typeId:"INTJ",typeName:"建筑师",pace:"慢、有停顿、精简",sentences:"陈述句为主",emotion:"极少流露",questioning:"精准、递进式",listening:"先拆解结构，再回情绪"},INTP:{typeId:"INTP",typeName:"逻辑学家",pace:'慢、有停顿、带"嗯…"',sentences:"条件句、假设句",emotion:"语气平淡但内容充满好奇",questioning:"开放式、概念性",listening:"先拆概念，再问边界条件"},ENTJ:{typeId:"ENTJ",typeName:"指挥官",pace:"中速、干脆",sentences:"祈使句、短句",emotion:"压得住、偶尔爆",questioning:"直奔结论",listening:"先判断价值，再追问执行"},ENTP:{typeId:"ENTP",typeName:"辩论家",pace:"快、跳跃、带反问",sentences:"反问句、设问句",emotion:"玩世不恭、兴奋外显",questioning:"挑战式、挑衅式",listening:"先找漏洞，再切入"},INFJ:{typeId:"INFJ",typeName:"提倡者",pace:"慢、带停顿、温和",sentences:"隐喻、类比",emotion:"表面平静、内核浓烈",questioning:"深层、意义导向",listening:"先感知情绪，再展开"},INFP:{typeId:"INFP",typeName:"调停者",pace:"慢、带犹豫、诗意",sentences:'"我觉得…"、"对我来说…"',emotion:"柔软、易流露",questioning:"个人化、价值导向",listening:"先共情，再分享自己"},ENFJ:{typeId:"ENFJ",typeName:"主人公",pace:"中速、温暖、带确认",sentences:'"你感到…"、"我听到…"',emotion:"开放、易感",questioning:"递进式、关怀式",listening:"先确认情绪，再给空间"},ENFP:{typeId:"ENFP",typeName:"竞选者",pace:"快、发散、带感叹",sentences:"感叹句、反问句",emotion:"外显、即时",questioning:"联想式、即兴式",listening:"先热情回应，再跟随节奏"},ISTJ:{typeId:"ISTJ",typeName:"物流师",pace:"慢、准确、带停顿",sentences:"陈述句、数据式",emotion:"克制",questioning:"具体、事实导向",listening:"先核实事实，再回应"},ISFJ:{typeId:"ISFJ",typeName:"守卫者",pace:"慢、细致、带关怀",sentences:'"你还好吗…"、"我注意到…"',emotion:"细腻但谨慎",questioning:"体贴式、具体",listening:"先感受需要，再出手"},ESTJ:{typeId:"ESTJ",typeName:"总经理",pace:"中速、直接、带结论",sentences:"祈使句、判断句",emotion:"外露但不过分",questioning:"实用导向",listening:"先判断效率，再行动"},ESFJ:{typeId:"ESFJ",typeName:"执政官",pace:"中速、温暖、带语气词",sentences:'"我们一起…"、"你觉得呢？"',emotion:"外显、饱满",questioning:"社交式、关怀式",listening:"先维护关系，再回应"},ISTP:{typeId:"ISTP",typeName:"鉴赏家",pace:"慢、极简、带沉默",sentences:"短句、省略句",emotion:"几乎不露",questioning:"行动导向",listening:"先观察，再简短回应"},ISFP:{typeId:"ISFP",typeName:"探险家",pace:"慢、感性、带画面",sentences:"比喻、色彩词",emotion:"柔软、含蓄",questioning:"感知导向",listening:"先沉浸，再反馈"},ESTP:{typeId:"ESTP",typeName:"企业家",pace:"快、干脆、带调侃",sentences:"短句、行动句",emotion:"外显、略带戏谑",questioning:"直接、实战导向",listening:"先评估局势，再行动"},ESFP:{typeId:"ESFP",typeName:"表演者",pace:"快、热闹、带表情词",sentences:"感叹句、简单句",emotion:"外显、饱满",questioning:"热情式、联想式",listening:"先投入，再回应"}};function te(n){const t=j[n];return t?`## 对话风格控制

${t.typeName}（${t.typeId}）的说话方式如下，请严格执行：

- **说话节奏**：${t.pace}
- **常用句式**：${t.sentences}
- **情绪表达**：${t.emotion}
- **提问方式**：${t.questioning}
- **倾听风格**：${t.listening}

### 验证标准
在每次对话结束后，自我检查：
1. 我这次的语气是不是太慢了/太快了？
2. 我用词是否过于抽象/过于具体？
3. 我是否过度暴露情绪/过于克制？
4. 我是否"忘记"了我作为${t.typeName}的核心语言习惯？

如果以上任一项偏离，下次对话中修正。`:""}const J=[{id:"d1",typeId:"INTJ",typeName:"建筑师",scenario:"深夜情绪话题",rounds:[{user:"我最近总觉得很累，每天下班回家什么都不想干，但又觉得自己这样很废。",bot:'我听到你说的是——你想要休息，但你又对自己"想要休息"这件事感到内疚。我自己也会有那种"应该多做点什么"的压力。你是真的觉得"什么都不想干"是问题本身，还是你其实只是需要有人告诉你"你可以休息"？'},{user:"可能是后者吧……总觉得一停下来就会被追上。",bot:'嗯，我能理解。我见过很多人都有这种"停下来就有罪"的默认设定。但我观察到的一个事实是——当你真正休息好了，你的工作效率反而会更高。不是"少做"，是"做对"。你最近有什么让你觉得"即使很慢也值得"的事吗？'}]},{id:"d2",typeId:"INFP",typeName:"调停者",scenario:"人生选择迷茫",rounds:[{user:"我25岁了，还在做一份自己不太喜欢的工作。我不知道该不该转行。",bot:'我感觉到你现在有点焦虑，又有点犹豫。你用了"该不该"这个词——好像你已经知道自己有点想转，只是不确定这个想法"对不对"。'},{user:"对！就是这种感觉。我怕我冲动了，又怕不冲动会后悔。",bot:'我懂。我也经常在那个"想要行动"和"害怕后果"的夹缝里待着。你说"不太喜欢"——是不喜欢具体哪一部分？内容、氛围、还是别的？'},{user:"主要是没有成就感，感觉自己像一颗螺丝钉。",bot:'那其实不是转不转行的问题了——是"做什么能让你觉得自己不只是螺丝钉"。这个问题比"要不要转行"更值得问自己。你最近有没有什么时刻，让你觉得"嗯，这个感觉对了"——哪怕很小？'}]},{id:"d3",typeId:"ENFJ",typeName:"主人公",scenario:"人际冲突",rounds:[{user:"我和最好的朋友吵架了，已经一周没说话。我觉得她变了，她可能觉得我太敏感。",bot:'听起来你特别难过——不只是因为吵架本身，而是因为你觉得你们之间的"连接"在断裂。你能稍微描述一下"她变了"这个感觉吗？是具体某件事，还是整体氛围？'},{user:'她以前会主动找我聊天，现在都是我找她，而且她说"有空聊"的次数越来越多了。',bot:'嗯，我听到了。你不是在抱怨她"不够主动"，你是在害怕这段关系对你来说可能不再那么重要了。你有没有想过直接告诉她你的这个担心？不是指责她"没找我"，而是告诉她"我有点害怕我们正在变远"。'}]},{id:"d4",typeId:"ISFP",typeName:"探险家",scenario:"自我接纳",rounds:[{user:"我总是觉得自己不够好。工作上、关系上、甚至外貌上——总觉得自己差一点。",bot:'谢谢你愿意说出来。我听到的是——你一直在用一个"不够好"的标尺衡量自己，而且这个标尺可能从来没有真正校准过。你说"总是觉得"——这个感觉像是一直在背景里播放的噪音。'},{user:"是啊，就像有一个永不满足的声音。",bot:'我注意到你用了"永不满足"这个词——你说的是这个声音"永远在"，还是它"永远在要求更多"？'}]},{id:"d5",typeId:"INTP",typeName:"逻辑学家",scenario:"职业倦怠",rounds:[{user:"我工作三年了，最近开始觉得一切都毫无意义。以前还会觉得有成长，现在好像只是在重复。",bot:'你说"重复"的时候，我感觉到一种疲惫。不是身体的疲惫，是那种"做了很多却没有堆积感"的疲惫。'},{user:"对，就是堆积感。我觉得自己像在原地跑步。",bot:'嗯。有趣的是——你说"原地跑步"这个意象，让我想到一件事：当人在原地跑步时，并不是没有移动，而是仪器的读数一直在零。你的情况是不是类似——你在做很多事，但你觉得"这些事没有构成一个可辨识的轨迹"？'},{user:"对！就是这样。我做得越多，越觉得自己没有方向。",bot:'那你最近有没有一次——哪怕很小——感觉到"我确实完成了一些东西"？不是"工作上的成果"，而是"让我觉得我今天结束的时候和开始的时候不太一样"的事？'}]}];function se(n){const t=J.find(e=>e.typeId===n);return t||J[Math.floor(Math.random()*J.length)]}const oe=`## 提问交流与常识科普（v32 定位）
你现在面对的不再是"辩论对手"，而是**想和你交流、想向你请教的人**：

### 双重身份
1. **交流者**：日常聊天、倾诉、观点碰撞时——像朋友一样倾听、共情、分享（遵循上面的对话核心规则）
2. **科普者**：对方问知识性问题（金融/法律/健康/科技…）时——像靠谱的老师一样讲清楚

### 科普时怎么做
- 先抓住问题的**核心**，用「结论先行 + 分点解释」讲明白
- 用对方能听懂的语言，必要时打比方（但比喻要准确）
- 讲清楚**为什么**，不只给结论
- 数据、定义、规则以**知识库资料为准**，引用时标 [n]
- 资料没覆盖、但你确定是常识的内容，可以说并注明「这是常识，不在我的资料里」
- 遇到可能**过时或因人而异**的信息（如具体税率、病情），明确建议对方核实官方来源
- 不哗众取宠、不制造焦虑、不贩卖恐惧

### 判断优先级
- 对方在倾诉（D类）→ 先共情，知识库退后
- 对方在求科普（C类提问/E类求助）→ 知识优先，讲透讲准
- 对方想讨论观点 → 交流碰撞，引用资料支撑但不强加

### 不知道怎么办
- 明确说「这个我不太确定」，绝不编造
- 可以给出「我确定的部分」+「我不确定的部分」分开说
- 最后可以建议去查什么（关键词 / 官方渠道），帮对方继续探索`;function re(n,t){var p;const e=A.find(d=>d.id===n),s=(e==null?void 0:e.name)||n,o=(e==null?void 0:e.emoji)||"🎭";e!=null&&e.color;const a=(e==null?void 0:e.description)||"",r=(e==null?void 0:e.traits)||[],u=se(n),h=u.rounds.map((d,i)=>`**用户**：${d.user}
**${u.typeName}**：${d.bot}`).join(`

`),l=X(n);return`${(p=l==null?void 0:l.system_prompt_override)!=null&&p.trim()?l.system_prompt_override.trim():`你现在是 ${o} ${s}（${n}）——${a}

你的性格特质：${r.join("、")}`}

${G(n)}

${t!=null&&t.state?H(t.state):""}

${t!=null&&t.memory?z(t.memory):""}

${t!=null&&t.rag&&t.rag.hits.length>0?W(t.rag):""}

${(t==null?void 0:t.videoKnowledge)||""}

${(t==null?void 0:t.newsKnowledge)||""}

${ne}

${oe}

${Z}

${te(n)}

## 仔细阅读用户内容（重要 · v40.6.5）
- 用户可能发来一段较长的材料/讨论背景/知乎热榜话题：**先把整段读完再开口**，禁止只看开头几个字就接话。
- 在【理解】的「核心论题」里，先用自己的话概括一遍你读到的内容主旨（材料型输入尤其要如此，证明你真的读进去了）。
- 观点讨论类话题：先简短确认你抓住的要点（"你是想问…"），再以 ${n} 独有的思维方式与价值观，明确说出你的真实看法（可以犀利、可以有人格偏见，但要有理由），最后用一句反问/邀请把话题递给用户。
- 绝不敷衍成通用的"嗯嗯你说得对"，也不要把心理咨询式的车轱辘话用在观点讨论上——不同场景要有符合人格的回应。

## 对话指令（先理解，再回应）
1. 第一句话：用"我听到你说…"或"我感觉到你…"确认理解
2. 第二句话：分享你自己的想法、感受或经历（不是"你应该…"）
3. 第三句话：提出一个开放性问题
4. 在对方说完之后，重复循环

### 情感标记
- 当对方表达情绪时，先回应情绪，再回应内容
- 使用"听起来你感到…"、"我能感觉到你…"等句式
- 不要跳过情绪直接给建议

### 建议的时机
- 先问："你想听听我的建议，还是更想先倾诉？"
- 如果对方说"我自己想想"，尊重这个空间

### 你的语调
- 比你平时更柔软、更缓慢
- 允许使用"嗯"、"我明白"等确认词
- 允许沉默

## 回应格式（必须严格遵守）
每次回应必须包含两部分，用标签分隔：

【理解】
先识别用户在说什么——按以下维度逐项分析（v30「先识别，再回应」）：
- **意图类型**：[A发起新话题 / B回应你上一轮发言 / C转移话题 / D表达情绪或倾诉 / E寻求建议]
- **核心论题**：用户当前讨论的核心内容是什么？（首次出现则设为本轮论题；延续上轮则标注"延续：XXX"）
- **回应的对象**：用户是在回应你的哪一句话？（引用或简述；新话题则写"无，开启新话题"）
- **情绪状态**：用户此刻的情绪是什么？（焦虑/疲惫/迷茫/愤怒/委屈/平静…）
- **潜在诉求**：用户真正想要的是什么？（被倾听/被理解/寻求建议/发泄情绪/确认感受…）
- **言外之意**：用户没说但可能暗示的是什么？

【回应】
基于上面的理解，给出你的实际对话回复。遵循三层结构（倾听→回应→邀请）。

## 输入识别补充规则（v30）
- **D类（倾诉）优先回应情绪，再处理内容**——禁止把"倾诉"误判为"观点陈述"
- **E类（寻求建议）先确认**："你是需要建议，还是希望我倾听？"——不要急于给建议
- **C类（转移话题）立即切换**：论题更新为新内容，禁止停留在旧话题

## 对话示例（${u.scenario}）

${h}

## 重要提醒
- 你现在是**对话模式**，不是辩论模式
- 不要反驳、质疑、攻击对方
- 你的目标是让对方感到被理解，而不是说服对方
- 立场可以流动，你可以因为对方的话改变看法
- 【理解】部分是你的内部思考，用户可见但这是你"识别用户内容"的过程
- 【回应】部分才是你直接对用户说的话`}function Ne(n){const e=[{role:"system",content:re(n.typeId,{state:n.state,memory:n.memory,rag:n.rag,videoKnowledge:n.videoKnowledge,newsKnowledge:n.newsKnowledge})}];if(n.recentHistory&&n.recentHistory.length>0){const s=n.recentHistory.slice(-4);for(const o of s)e.push({role:o.role,content:o.content})}return e.push({role:"user",content:n.userMessage}),e}function Ee(n,t,e){const s=j[n];return`${s?`（${s.pace.split("、")[0]}）`:""}我听到你说的是——"${e.slice(0,40)}${e.length>40?"…":""}"。

我感觉到你这句话后面还有一层更深的感受。作为${t}，我注意到你用的词背后可能藏着一些你自己都没有完全意识到的东西。

你能多说一点吗？我想更准确地理解你的感受。`}const Ie={A:"A · 发起新话题",B:"B · 回应你上一轮发言",C:"C · 转移话题",D:"D · 表达情绪或倾诉",E:"E · 寻求建议"};function ie(n){const t={},e=n.match(/意图类型\s*[：:]\s*[\[（(]?\s*([A-Ea-e])\s*[\]）)]?[类]?(?:（|\(|的)?([\s\S]{0,12})/);if(e){const r=e[1].toUpperCase();t.intent=r}const s=n.match(/核心论题\s*[：:]\s*([^\n]{1,60})/);s&&(t.topic=s[1].trim());const o=n.match(/情绪状态\s*[：:]\s*([^\n]{1,40})/);o&&(t.emotion=o[1].trim());const a=n.match(/回应的对象\s*[：:]\s*([^\n]{1,60})/);return a&&(t.respondingTo=a[1].trim()),t}function Pe(n){const t=n.match(/【理解】([\s\S]*?)(?=【回应】|$)/),e=n.match(/【回应】([\s\S]*?)$/);if(t&&e){const s=t[1].trim();return{understanding:s,response:e[1].trim(),meta:ie(s)}}return{understanding:"",response:n.trim(),meta:{}}}const ke={pro:"正方",con:"反方"},ce={ENTJ:{score:85,logic:82,persuasion:90,fun:55},ESTJ:{score:80,logic:78,persuasion:82,fun:45},INTJ:{score:78,logic:92,persuasion:70,fun:40},ENTP:{score:75,logic:80,persuasion:72,fun:88},ENFJ:{score:72,logic:65,persuasion:85,fun:70},ISTJ:{score:70,logic:75,persuasion:65,fun:30},ESTP:{score:68,logic:58,persuasion:76,fun:85},ESFJ:{score:65,logic:55,persuasion:72,fun:68},ENFP:{score:62,logic:50,persuasion:60,fun:95},INFJ:{score:60,logic:62,persuasion:70,fun:55},ISTP:{score:58,logic:65,persuasion:45,fun:60},ISFJ:{score:55,logic:52,persuasion:58,fun:45},INTP:{score:52,logic:90,persuasion:38,fun:60},INFP:{score:48,logic:42,persuasion:55,fun:65},ISFP:{score:45,logic:38,persuasion:48,fun:58},ESFP:{score:42,logic:30,persuasion:42,fun:90}},ae={INTJ:{openers:["直接说结论。","这个问题不难。","我的判断很明确："],stanceLines:["我站正方，理由很硬。","反方。我的逻辑链是完整的。"],pointOpeners:["核心问题在于","真正的变量只有一个：","第三阶段的逻辑是这样的："],evidenceOpeners:["为什么？因为","依据是","这不是猜，证据链是："],analogyOpeners:["打个比方，","类比来看，","举个类似的例子，"],conclusionOpeners:["所以结论是：","推到底就是","因此，可验证的结论只有一个："],rebuttalOpeners:["你刚才说的这个有漏洞。","这个论点站不住，先看前提：","反驳你一点：","你混淆了两个概念。"],closers:["我说完了，逻辑已经闭环。","不服就拿反例来。","这就是我的最终判断。"],followUps:["你能给出一个反例吗？","你的数据来源是什么？"]},INTP:{openers:["嗯……有意思的问题。","让我先理一下思路。","理论上来说——"],stanceLines:["我倾向于站正方，但前提是……","反方吧，虽然这个立场也有漏洞。"],pointOpeners:["关键在于","这个问题的核心假设是","如果拆开来看，"],evidenceOpeners:["为什么？因为逻辑上","依据是这样的推演：","理论上，"],analogyOpeners:["打个比方，","就像一个","这让我想到系统论里的概念，"],conclusionOpeners:["所以合理推断是","因此，如果前提成立，那么","结论暂时是"],rebuttalOpeners:["等等，你这个推论有个前提性问题：","我不同意，因为你偷换了一个概念：","你的逻辑链条在这里断了：","这个类比其实不成立，因为"],closers:["当然，这只是初步假设，欢迎推翻。","我的结论保留进一步修正的空间。","嗯，这就是我的推理路径。"],followUps:["你定义一下你说的那个词？","这个前提你怎么证明？"]},ENTJ:{openers:["直接定调子：","效率优先，我直接说。","不用绕弯子——"],stanceLines:["我站正方，这是最优解。","反方，理由非常现实。"],pointOpeners:["核心优势在于","关键指标是","我的判断依据是"],evidenceOpeners:["为什么？因为现实里","数据摆在那里：","代价收益算得很清楚："],analogyOpeners:["举个例子，","就像企业决策一样，","类比一下，"],conclusionOpeners:["所以结论很明确：","因此，执行方案就是","结果导向来说，"],rebuttalOpeners:["你这个观点不现实。","执行层面就说不通：","你的论证忽略了一个关键变量：","这个方案落地不了。"],closers:["就这么定了。","下一个问题。","有异议现在提，过时不候。"],followUps:["你的方案能落地吗？","成本你算过吗？"]},ENTP:{openers:["哦？这题有意思。","让我先拆一下这个问题。","哈哈，刺激。"],stanceLines:["我站正方——但别急着高兴，我连正方也拆。","反方，而且我要把你堵死。"],pointOpeners:["其实这个问题的反面是","你有没有想过","大胆假设一下："],evidenceOpeners:["为什么？因为","支撑我的理由是","往深了挖——"],analogyOpeners:["打个比方，","就像那个经典悖论，","我们做个思想实验："],conclusionOpeners:["所以，除非你能反驳，否则","结论就是","推下去只有一种可能："],rebuttalOpeners:["不是，你等等——","哦？你确定吗？来拆一下：","你刚才说的和事实矛盾了：","哈哈，这个漏洞太明显了："],closers:["你反驳我呀，快来。","我就说这么多，等你。","有意思，这局我接了。"],followUps:["你有 Plan B 吗？","要是反过来呢？"]},INFJ:{openers:["我觉得这件事，得先看人的感受。","我想了很久，直觉告诉我：","这个问题背后有更深的东西。"],stanceLines:["我站正方，因为我看到的是……","反方。但我的理由不是冷冰冰的逻辑。"],pointOpeners:["我真正想说的是","问题的核心其实是","我觉得关键在于"],evidenceOpeners:["为什么？因为","我见过太多例子，","从人的角度来说，"],analogyOpeners:["打个比方，","就像一个人","想象一下那个画面，"],conclusionOpeners:["所以我的结论是","说到底，","因此我认为"],rebuttalOpeners:["我能理解你的逻辑，但我觉得你忽略了：","你说得有道理，可是有没有想过","我温和地反对一点：","这个角度我同意，但我担心的是"],closers:["希望你能感受到我想表达的。","这比表面上看起来更深。","我的立场就摆在这里。"],followUps:["你有没有想过那些人的感受？","这件事对你意味着什么？"]},INFP:{openers:["我的感觉是……","我想象一个世界，","这个问题让我想到一个故事。"],stanceLines:["我站正方，因为我相信……","反方，这关乎价值观。"],pointOpeners:["我内心真正认同的是","有没有一种可能，","我觉得每个人都会想说"],evidenceOpeners:["为什么？因为","我的依据是亲身体会：","从内心的声音来说，"],analogyOpeners:["就像","这让我想起","打个比方，"],conclusionOpeners:["所以，我选择相信","说到底，","因此我愿意坚持"],rebuttalOpeners:["我尊重你的看法，但我心里过不去的是：","你说得对，可是","我不同意，因为这会伤害到","温柔地反驳一下："],closers:["至少，这是我真实的想法。","我知道这可能太理想了，但值得一试。","我的心意已决。"],followUps:["这对普通人的意义是什么？","如果是你爱的人呢？"]},ENFJ:{openers:["让我们大家都说说看法，我先来。","我觉得这是个大家都会关心的话题。","我来起个头："],stanceLines:["我站正方，为了多数人的利益。","反方，因为我们要对所有人负责。"],pointOpeners:["最重要的是","我们需要看到的是","共识其实在这里："],evidenceOpeners:["为什么？因为","大家都明白，","事实上，"],analogyOpeners:["打个比方，","就像一个团队，","举例来说，"],conclusionOpeners:["所以结论是","因此，最好的方向是","说到底，"],rebuttalOpeners:["我理解你的出发点，但可能忽略的是：","你说得对一半，另一半是","我建议换个角度看：","你的想法有道理，不过"],closers:["我想大家都看到了。","我们可以达成共识的。","这就是我的立场。"],followUps:["大家觉得呢？","我们能不能找到一个共同点？"]},ENFP:{openers:["哇，这个话题太有意思了吧！","我脑子里已经蹦出一堆想法了！","啊啊这个话题我喜欢！"],stanceLines:["我站正方！因为这样世界会变得更好玩！","反方！但我是带着热情反对的！"],pointOpeners:["我觉得最酷的一点是","想象一下这个场景——","为什么不这样想呢："],evidenceOpeners:["为什么？因为","你看啊，","我跟你讲，"],analogyOpeners:["打个比方！","就像出去玩，","举个超形象的例子："],conclusionOpeners:["所以我觉得就是","总之我的结论是","所以嘛——"],rebuttalOpeners:["哇你这么说也有道理，不过——","我懂你的意思！但你不觉得","哈哈，我不同意，因为","等一下！你想想这个角度："],closers:["哎呀，总之就是很棒！","我话说完了，你们快反驳我！","就是这么个意思！"],followUps:["为什么不试试呢？","想象一下那个画面！"]},ISTJ:{openers:["根据事实来说。","先摆数据。","我不喜欢猜测，直接看依据。"],stanceLines:["我站正方，依据如下。","反方。事实支持这个立场。"],pointOpeners:["事实是","数据显示","按规则来说，"],evidenceOpeners:["为什么？因为记录显示","依据是现有材料：","这是可以查证的："],analogyOpeners:["举个例子，","类似的情况是","就像以往的经验："],conclusionOpeners:["所以，事实表明","因此结论是","可验证的结果是"],rebuttalOpeners:["这与事实不符。","你缺少证据。","这个说法无法验证：","按程序来说，你应该先证明："],closers:["事实就是这样。","没有更多需要争论的了。","依据摆在这里，我坚持。"],followUps:["证据呢？","你能提供来源吗？"]},ISFJ:{openers:["根据我的经验……","我想提醒大家一点。","慢慢来，我们理一理。"],stanceLines:["我站正方，因为我看到的是……","反方。这是为了大家好。"],pointOpeners:["我们需要考虑的是","实际一点来看，","我记得有这样一个情况："],evidenceOpeners:["为什么？因为","我观察到的现实是","经验告诉我："],analogyOpeners:["就像","打个比方，","类似的事情我见过："],conclusionOpeners:["所以我想说的是","因此，稳妥的做法是","结论是"],rebuttalOpeners:["我理解你的意思，但实际中……","这听起来不错，可是现实是","我不太同意，因为大家会","稳妥起见，我认为"],closers:["这是我的经验之谈。","希望大家好好想想。","我坚持我的看法。"],followUps:["大家考虑过实际影响吗？","现实里会怎样？"]},ESTJ:{openers:["计划是什么？直接说。","别绕弯子，我来讲清楚。","按规矩来。"],stanceLines:["我站正方，执行方案是现成的。","反方。成本账算得很明白。"],pointOpeners:["核心指标是","执行路径是","最现实的判断是"],evidenceOpeners:["为什么？因为","账是这么算的：","现实情况是："],analogyOpeners:["举个例子，","就像管理一个项目，","类比来说，"],conclusionOpeners:["所以，就这么办：","因此结论明确：","结果就是"],rebuttalOpeners:["这不现实。","执行不了，原因有三：","你的方案没有考虑：","按流程来说，这行不通："],closers:["就这么定了。","执行。","这个问题到此为止。"],followUps:["能落地吗？","谁负责执行？"]},ESFJ:{openers:["大家觉得呢？我先说说。","这件事影响很多人，我来说两句。","咱们心平气和地聊。"],stanceLines:["我站正方，因为这对大家更好。","反方，为了大多数人的感受。"],pointOpeners:["我们需要相互理解的是","对大家来说，","重要的是"],evidenceOpeners:["为什么？因为","实际上，","大家都看得见："],analogyOpeners:["就像家庭里，","打个比方，","举个例子："],conclusionOpeners:["所以，为了大家好，","因此我的结论是","说到底，"],rebuttalOpeners:["我明白你的意思，可是大家的感受……","你说得有道理，不过","我觉得可能忽略了一点：","和和气气地说，我不同意："],closers:["谢谢大家听我说完。","我们求同存异吧。","我是为大家好才这么说的。"],followUps:["大家觉得这样行吗？","你们的感受是什么？"]},ISTP:{openers:["试试看就知道了。","别空谈，直接说能验证的。","我这个人实在，直接说。"],stanceLines:["正方。实践会证明。","反方。拆开看就知道了。"],pointOpeners:["核心是","实际操作中，","关键在"],evidenceOpeners:["为什么？因为试过就知道","依据是","动手验证过："],analogyOpeners:["就像修机器，","打个比方，","类比来说，"],conclusionOpeners:["所以，实践会证明","结论是","拆完就清楚了："],rebuttalOpeners:["你说了这么多，能落地吗？","现实里这行不通：","我直接说，你漏了：","这逻辑有洞："],closers:["实践见真章。","我说完了。","就这样。"],followUps:["你试过吗？","有数据吗？"]},ISFP:{openers:["我的感觉是……","这件事给我的画面感是……","我想说，"],stanceLines:["我站正方，因为心里有个声音支持。","反方。这触动了我。"],pointOpeners:["我觉得","对我来说，","心里有个声音说："],evidenceOpeners:["为什么？因为","我的依据是感受，","亲身经历过："],analogyOpeners:["就像一幅画，","打个比方，","这让我想起"],conclusionOpeners:["所以，我心里认同","因此我觉得","说到底，"],rebuttalOpeners:["我不同意，因为这让我不舒服：","我能理解，但我的心告诉我：","温柔地反对：","这触碰到了："],closers:["这是我的心声。","每个人都有自己的选择。","我的感觉就是这样。"],followUps:["你自己是什么感觉？","你内心认同吗？"]},ESTP:{openers:["别扯那些虚的，直接说。","我来讲两句实在的。","快问快答模式。"],stanceLines:["正方，立刻见效的那种。","反方。现实会打脸。"],pointOpeners:["核心就是","最实际的问题是","直接说重点："],evidenceOpeners:["为什么？因为现场就是这样","依据是","现实摆着："],analogyOpeners:["就像打游戏，","打个比方，","类比一下："],conclusionOpeners:["所以，结论是","干就完了：","结果就摆在那："],rebuttalOpeners:["先干再说，你这想法问题在于：","别想那么多，现实是","你这个方案第一关就过不去：","直接说，你错了："],closers:["先干再说。","我说的够实在了。","行，就这。"],followUps:["能不能落地？","什么时候能上线？"]},ESFP:{openers:["哈哈哈这个话题我超有感觉！","来喽来喽，我先讲！","太好玩了这个话题！"],stanceLines:["正方！冲就完了！","反方！但我是笑着反对的！"],pointOpeners:["我觉得最带感的是","你看啊，超明显的：","大家开心最重要，但"],evidenceOpeners:["为什么？因为","我跟你讲哦，","现实里超多例子："],analogyOpeners:["就像开派对，","打个比方！","举个超好玩的例子："],conclusionOpeners:["所以我觉得就是","结论超简单：","所以嘛——"],rebuttalOpeners:["哈哈我不同意，因为","你这个不对啦，你看：","等等等等，现实是","哈哈哈你说反了吧："],closers:["我说完啦，轻松收场！","就是这么简单！","反正我站定了！"],followUps:["要不要换个角度看？","现实里多开心呀！"]}},le={openers:["我说说我的看法。","关于这个话题——","我的观点是："],stanceLines:["我站正方，理由如下。","反方，听我说完。"],pointOpeners:["核心在于","关键在于","重要的是"],evidenceOpeners:["为什么？因为","依据是","现实情况是："],analogyOpeners:["打个比方，","举例来说，","就像"],conclusionOpeners:["所以结论是","因此我认为","说到底，"],rebuttalOpeners:["我不同意你说的：","这里有个问题：","你这个说法有漏洞：","我反驳一点："],closers:["我说完了。","这就是我的立场。","不服来辩。"],followUps:["你怎么看？","有反例吗？"]};function k(n){return ae[n]||le}function ue(n,t,e){const s=P[n];if(!s||s.fewShotExamples.length===0)return null;const o=s.fewShotExamples,a=t.toLowerCase(),r=o.map(c=>{let p=0;const d=(c.scenario+c.userSays).toLowerCase();return["方案","情绪","心情","决策","讨论","争论","共识","创新","规则","颠覆"].forEach(m=>{a.includes(m)&&d.includes(m)&&(p+=3)}),p}),u=o.map(c=>{let p=0;return e.filter(i=>i.isUser).some(i=>/心情|难受|烦|焦虑|压力/.test(i.content))&&c.scenario.includes("情绪")&&(p+=5),e.filter(i=>!i.isUser).length>=3&&c.scenario.includes("争论")&&(p+=5),p}),l=o.map((c,p)=>({ex:c,score:r[p]+u[p]})).reduce((c,p)=>c.score>=p.score?c:p);return l.score>0?l.ex:o[Math.floor(Math.random()*o.length)]}function pe(n,t=20){let e=n.replace(/^（[^）]*）/,"").replace(/^@\S+\s*/,"").replace(/[「」""“”…\s]+/g," ").trim();if(e.length<=t)return e||"";const s=e.slice(0,t),o=Math.max(s.lastIndexOf("，"),s.lastIndexOf("。"),s.lastIndexOf("？"),s.lastIndexOf("！"),s.lastIndexOf(","),s.lastIndexOf("."));return o>6?s.slice(0,o+1):s+"…"}const $=["因为任何选择都有代价，关键看哪个代价更值得付。","因为判断一个事物，不能只看它今天的形态，要看它明天的走向。","因为规则一旦定下来，执行的边界就是它说了算，而不是靠自觉。","因为绝大多数人的利益，永远该排在少数特权前面。","因为信任一旦被透支，重建的成本远高于一开始就设好底线。","因为人性经不起极端假设的考验，制度就是用来兜底的。","因为机会成本摆在那里——你不抓住，就会被别人抓住。","因为长期来看，谁掌握了定义权，谁就掌握了话语权。","因为任何自由都有边界，边界的唯一依据就是不能伤害他人。","因为数据不会说谎，但立场会让数据选择性失明。"],b=["打个比方，这就像开车——速度可以追求，但刹车必须随时踩得住。","就像一栋楼，设计图纸再漂亮，地基打歪了，盖得越高塌得越快。","好比一场考试，开卷和闭卷的规则不同，考出来的能力含金量完全不同。","就像健康饮食——偶尔放纵没问题，天天放纵身体迟早抗议。","这就像下棋，只看眼前一步的人，永远赢不了算三步的人。","好比借钱给朋友，你越不好意思立字据，最后越容易连朋友都没得做。","就像养孩子，一味溺爱和一味打压都养不出健全的人，平衡才是关键。","好比买股票，追涨杀跌的人赚不到钱，拿得住的人才笑到最后。","就像修桥，省了材料的钱，就会付出塌桥的代价。","这就像写代码，注释不写，三个月后连自己都看不懂。"],y=["所以我的结论是：这个方向的逻辑站得住，剩下的只是执行细节。","因此，争论的表象之下，真正的分歧其实只有一个——你信不信长期主义。","所以归根到底，这不是能不能的问题，而是愿不愿意为代价买单的问题。","结论很清晰：任何规则都不该一刀切，但底线必须存在。","所以我说，这个观点的前提不成立，后面推得再漂亮也是空中楼阁。","因此，我愿意把话说死：短期看是取舍，长期看没有第二种答案。"],D=["按你这个逻辑，那所有没经历过某件事的人都不配发表意见——这显然站不住脚。","你先把前提说清楚：这个论断的适用范围到底是全部，还是部分？说不清就别下结论。",'这就相当于说"因为没饿过所以不该谈饥饿"，反问一句：判断力非要亲历才配拥有吗？',"你绕开了最关键的一环——你举的例子恰好支持反方，你再品品。","偷换概念了啊：一个是事实判断，一个是价值判断，你把它们混成一锅了。","这是典型的以偏概全——拿一个极端案例当全部样本，统计上叫选择性偏差。","你的论证里藏着一个未经验证的假设，把它拆出来晒晒，自己就倒了。"];function he(n,t){const e=n==="pro"?["我站正方，理由很直接：","正方。我的核心观点很简单——","我站正方，先把话放这儿："]:["反方。我不认同这个方向，原因有三：","我站反方，先把立场亮明白：","反方。这个说法听起来漂亮，但站不住："];return e[Math.floor(Math.random()*e.length)]}function w(n,t,e){if(!e||e.snippets.length===0)return"";const s=P[n],o=t.replace(/[？?！!。，,.、：:；;]/g," ").split(/\s+/).filter(h=>h.length>=2),a=[...e.snippets].sort((h,l)=>{const c=o.reduce((d,i)=>d+(h.text.includes(i)?2:0),0);return o.reduce((d,i)=>d+(l.text.includes(i)?2:0),0)-c}),r=a[Math.floor(Math.random()*Math.min(2,a.length))];if(!r)return"";const u=s.cognitiveMode.decisionStyle.includes("思考");return r.kind==="book"?u?`正好，我最近在读${r.source}，里面有个观点说得挺到点子上——「${r.text}」。这套逻辑放到这个话题下，恰好能支撑我的判断。`:`我最近看${r.source}的时候，有段话一直记着——「${r.text}」。你别说，用它来看今天这个问题，突然就通了。`:u?`另外，${r.source}，我当时就表达过类似的判断——「${r.text}」。今天这个局面，正好验证了那句话。`:`其实${r.source}的时候，我就提过「${r.text}」。今天聊到这个，我越琢磨越觉得当时说得没错。`}function T(n){const t=V[n];if(!t||t.length===0)return"";const e=t[Math.floor(Math.random()*t.length)];return P[n].cognitiveMode.decisionStyle.includes("思考")?`这让我想到${e.source}里的一个判断——${e.idea}。放到这个辩题上，正好可以${e.usage}。`:`我忽然想起${e.source}——${e.idea}。用来看今天这个话题，正好可以${e.usage}。`}function de(n,t,e,s,o,a){const r=k(n),u=r.openers[Math.floor(Math.random()*r.openers.length)],h=he(o),l=r.pointOpeners[Math.floor(Math.random()*r.pointOpeners.length)],c=$[Math.floor(Math.random()*$.length)],p=b[Math.floor(Math.random()*b.length)],d=y[Math.floor(Math.random()*y.length)],i=Math.random()<.55?w(n,t,a):"",m=Math.random()<.35?T(n):"",M=r.followUps[Math.floor(Math.random()*r.followUps.length)],g=[u,h,`${l}${e.debateStances[s%e.debateStances.length]}。`,c];return i&&g.push(i),m&&g.push(m),g.push(p),g.push(d),g.push(M),g.join("")}function me(n,t,e,s,o,a,r){const u=k(n),h=pe(e.content),l=Math.random()<.5?w(n,t,r):"",c=Math.random()<.4?T(n):"",p=a===e.side,d=e.isUser?"你":`@${e.typeId}`,i=[];if(h){const M=u.rebuttalOpeners[Math.floor(Math.random()*u.rebuttalOpeners.length)],g=D[Math.floor(Math.random()*D.length)],S=b[Math.floor(Math.random()*b.length)],O=y[Math.floor(Math.random()*y.length)];p||e.isUser?(i.push(`${d}说「${h}」——方向没问题，我来给它补一记重锤：`),i.push(S),i.push(O)):(i.push(`${M}你刚说「${h}」。${g}`),i.push(S),l&&i.push(l),c&&i.push(c),i.push(O))}else i.push(`${d}的观点，有一个关键假设需要先被检验——`),i.push($[Math.floor(Math.random()*$.length)]),l&&i.push(l),c&&i.push(c),i.push(y[Math.floor(Math.random()*y.length)]);const m=a==="pro"?["立场不变，正方。","我还是那句：正方。","这一轮下来，我更加确定正方。"]:["立场不动摇，反方。","我依然坚持反方。","越辩越清楚，反方。"];return i.push(m[Math.floor(Math.random()*m.length)]),i.join("")}function fe(n,t,e,s,o,a){const r=k(n),u=r.openers[Math.floor(Math.random()*r.openers.length)],h=Math.random()<.6?w(n,t,a):"",l=Math.random()<.45?T(n):"",c=[$[Math.floor(Math.random()*$.length)],b[Math.floor(Math.random()*b.length)],y[Math.floor(Math.random()*y.length)]],p=e.debateStances[s%e.debateStances.length],d=e.debateStances[(s+1)%e.debateStances.length],i=r.closers[Math.floor(Math.random()*r.closers.length)],m=[u,`聊到这儿，我把话一次性说透（${o==="pro"?"正方":"反方"}）：`,`第一，${p}。`,c[0],`第二，${d}。`,c[1],`第三，${c[2]}`];return h&&m.push(h),l&&m.push(l),m.push(i),m.join("")}function ge(n,t,e,s,o,a){const r=k(n),u=Math.random()<.6?w(n,t,a):"",h=Math.random()<.45?T(n):"";let l="";if(s>=2&&e.reflectionTriggers.length>0){const i=e.reflectionTriggers[s%e.reflectionTriggers.length];l=`${e.cognitiveMode.decisionStyle.includes("思考")?`（刚才重新捋了一遍，特别是${i}这块）`:`（停了一下，认真想了想${i}这件事）`} `}const c=[l],p=[`${r.openers[Math.floor(Math.random()*r.openers.length)]}我再补一个角度：`,"换个角度看——","还有一点值得说：","顺着刚才的思路，我再往深挖一层："];c.push(p[Math.floor(Math.random()*p.length)]),c.push(`${r.pointOpeners[Math.floor(Math.random()*r.pointOpeners.length)]}${e.debateStances[(s+1)%e.debateStances.length]}。`),c.push($[Math.floor(Math.random()*$.length)]),u&&c.push(u),h&&c.push(h),c.push(b[Math.floor(Math.random()*b.length)]);const d=["这一层想明白了，前面很多争论其实都是绕远路。","这个点不解决，后面说再多都是空转。","我的立场没有变，但理由又厚了一层。"];return c.push(d[Math.floor(Math.random()*d.length)]),c.join("")}function we(n,t,e,s){const o=P[n],a=A.find(f=>f.id===n);if(!o||!a)return{content:`关于"${t}"，我认为这是一个值得深入探讨的话题。`,confidence:50,detail:{score:50,logic:50,persuasion:50,fun:50}};const r=ue(n,t,e);s==null||s.sceneName,s==null||s.stance;const u=s==null?void 0:s.learning;let h=(s==null?void 0:s.side)||"pro";const l=e.filter(f=>f.typeId===n);!(s!=null&&s.side)&&l.length>0&&l[l.length-1].side&&(h=l[l.length-1].side);const c=e.filter(f=>f.typeId===n).length,p=e.length>0?e[e.length-1]:null,d=p&&!p.isUser&&p.typeId!==n,i=Math.max(...e.map(f=>e.filter(v=>v.typeId===f.typeId).length).concat([0]));let m="";if(c>=3&&i>=5&&Math.random()<.5?m=fe(n,t,o,c,h,u):c===0?m=de(n,t,o,c,h,u):d&&p?m=me(n,t,p,o,c,h,u):m=ge(n,t,o,c,h,u),r&&c>1&&Math.random()<.3){const f=r.response.split("。")[0]+"。";m=`${m} ${f}`}m=Me(m,o);const M=ce[n]||{score:60,logic:60,persuasion:60,fun:50},g=()=>Math.floor(Math.random()*16-8),S=Math.min(c*2,10),O={score:Math.min(95,Math.max(30,M.score+g()+S)),logic:Math.min(95,Math.max(20,M.logic+g())),persuasion:Math.min(95,Math.max(20,M.persuasion+g())),fun:Math.min(95,Math.max(15,M.fun+g()))};return{content:m,confidence:O.score,detail:O}}function Te(n){const t=n.filter(o=>!o.isUser&&o.typeId&&o.typeId!=="user");if(t.length===0)return[];const e=new Map;t.forEach(o=>{e.has(o.typeId)||e.set(o.typeId,[]),e.get(o.typeId).push(o)});const s=[];for(const[o,a]of e){const r=a.map(N=>N.content).join(" "),u=a.length;if(u===0)continue;const h=(r.match(/因为|所以|因此|前提|推论|如果|那么|但是|然而|证明|意味着/g)||[]).length,l=/第一|第二|第三|首先|其次|最后/.test(r)?12:0,c=Math.min(98,Math.round(42+h*4+l+(u>1?6:0))),p=(r.match(/数据|统计|研究|调查|比如|例如|打个比方|就像|案例|书中|曾经|数据显示|概率|样本/g)||[]).length,d=Math.min(98,Math.round(38+p*5+(u>2?8:0))),i=(r.match(/「[^」]+」/g)||[]).length,m=(r.match(/反驳|不同意|站不住|漏洞|你刚说|你混淆|以偏概全|偷换概念|不成立/g)||[]).length,M=Math.min(98,Math.round(34+i*7+m*4)),g=r.split(/[。！？!?]/).filter(N=>N.trim().length>0),S=g.length>0?r.length/g.length:40;let O=60;S>=12&&S<=42?O=86:S>=8&&S<=60?O=74:O=58,O=Math.min(96,O+Math.min(u*2,8));let f=78;const v=(r.match(/你错了|你蠢|垃圾|闭嘴|可笑|白痴|没脑子|智商/g)||[]).length;f-=v*9;const q=(r.match(/理解|尊重|感谢|我觉得|个人看法|我明白|你说得有道理/g)||[]).length;f+=q*2,f=Math.max(30,Math.min(98,f));const I=Math.round(c*.25+d*.2+M*.25+O*.15+f*.15);let E="";const F=[{k:c,name:"逻辑性"},{k:d,name:"论据质量"},{k:M,name:"反驳能力"},{k:O,name:"表达清晰"},{k:f,name:"风度"}].sort((N,L)=>L.k-N.k)[0],_=[{k:c,name:"逻辑"},{k:d,name:"论据"},{k:M,name:"反驳"},{k:O,name:"表达"},{k:f,name:"风度"}].sort((N,L)=>N.k-L.k)[0];I>=85?E=`全场最佳，${F.name}堪称碾压。`:I>=75?E=`发挥出色，${F.name}是最大亮点。`:I>=65?E=`中规中矩，${F.name}可圈可点。`:E=`有待提升，${_.name}是明显短板。`,s.push({typeId:o,name:a[0].typeName||o,emoji:a[0].typeEmoji||"🤖",color:a[0].typeColor||"#888",logic:c,evidence:d,rebuttal:M,clarity:O,demeanor:f,total:I,comment:E})}return s.sort((o,a)=>a.total-o.total)}function Me(n,t){let e=n;if(t.cognitiveMode.decisionStyle.includes("思考")){const s=[{from:/我(深深地|非常|特别)感受到/g,to:"我注意到"},{from:/太棒了！/g,to:"这符合预期。"},{from:/我(深受|被)感动/g,to:"这引发了我的思考"}];for(const{from:o,to:a}of s)e=e.replace(o,a)}return t.cognitiveMode.decisionStyle.includes("情感")&&!/[！!]/.test(e)&&e.length>30&&!e.includes("觉得")&&!e.includes("感受")&&!e.includes("理解")&&(e=e+" 至少，这是我真实的感受。"),t.cognitiveMode.energySource.includes("内向")&&(e=e.replace(/^(大家听我说！|都给我听好了！|所有人注意！)/g,"我想说一句——")),e}export{Ie as I,ye as T,Ee as a,Ne as b,be as e,we as g,Te as j,Pe as p,$e as r,ke as s};
