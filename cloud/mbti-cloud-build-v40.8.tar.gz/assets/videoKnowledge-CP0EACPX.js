import{K as y,a0 as f,ab as p,Y as k}from"./index-D73C-PiX.js";const h="mbti_video_books",l="videos",g=typeof localStorage<"u";let a=null;function b(t){const n=t.replace(/\r\n/g,`
`).split(/\n\s*\n/),i=[];for(const s of n){const o=s.split(`
`).map(c=>c.trim()).filter(Boolean);if(o.length===0)continue;o.length>=1&&/^\d+$/.test(o[0])&&o.shift(),o.length>=1&&/-->/.test(o[0])&&o.shift();const r=o.join(" ").trim();r&&i.push(r)}return i.join(`
`)}function v(t){const n=t.replace(/\r\n/g,`
`).replace(/^\uFEFF/,"").replace(/^WEBVTT[^\n]*\n+/,""),i=[];for(const s of n.split(`
`)){const o=s.trim();o&&(/-->/.test(o)||/^NOTE\b/i.test(o)||/^kind:|^language:|^cue\b/i.test(o)||/^\d{1,2}:\d{2}:\d{2}[.,]\d{3}$/.test(o)||/^\d+$/.test(o)||i.push(o))}return i.join(`
`)}function B(t,e){const n=t.toLowerCase();return n.endsWith(".srt")?b(e):n.endsWith(".vtt")?v(e):e.replace(/\r\n/g,`
`).split(`
`).filter(s=>!/^\s*\d+\s*$/.test(s)&&!/-->\s*\d/.test(s)).join(`
`).trim()}function d(){if(g)try{const t=localStorage.getItem(h);if(!t)return a?[...a]:[];const e=JSON.parse(t);return Array.isArray(e)?e:[]}catch{}return a?[...a]:[]}function u(t){if(a=[...t],!!g)try{if(localStorage.setItem(h,JSON.stringify(t.slice(0,100))),typeof window<"u")try{window.dispatchEvent(new CustomEvent("mbti:video-books-changed",{detail:t}))}catch{}}catch{}}function V(){return"vb_"+Date.now().toString(36)+Math.random().toString(36).slice(2,6)}async function K(t){const e=t.text.replace(/\r\n/g,`
`).trim(),n=V(),i=p(e).map((c,w)=>({text:c,title:t.title||"视频知识",fileName:t.title||`video-${n}`,seq:w}));let s=0,o;try{const c=await k(l,t.title||`video-${n}`,t.title||"视频知识","video",i,e.length);s=c.chunkCount,o=c.docId}catch(c){console.warn("[VideoKB] 内容入库失败（仅保存元数据）:",c)}const r={id:n,docId:o,title:t.title||"未命名视频",sourceUrl:t.sourceUrl,emoji:t.emoji||"📺",tags:(t.tags||[]).filter(Boolean).slice(0,8),summary:t.summary,transcript:e,sourceKind:t.sourceKind,addedAt:Date.now(),chunkCount:s};return u([r,...d()]),r}async function $(t){const e=d(),n=e.find(i=>i.id===t);if(n)try{await f(l,n.docId||t)}catch{}u(e.filter(i=>i.id!==t))}async function I(){const t=d();for(const e of t)try{await f(l,e.docId||e.id)}catch{}u([])}async function m(t,e=4){try{return(await y(l,t,e)).map(i=>({title:i.title||"视频知识",text:i.text,score:i.score}))}catch{return[]}}async function j(){const t=d();let e=0;for(const n of t)e+=n.chunkCount||0;if(e===0&&t.length>0)try{e=(await m("视频 知识 内容 资料",1)).length}catch{}return{count:t.length,chunkCount:e}}function S(t){return!t||t.length===0?"":`## 你学过的视频知识（来自「📺 视频收藏」）

以下是你曾经看过并收藏的科普视频提炼出的文字。它们是你「学过的内容」——回答/辩论时，**如果能贴合主题，请自然地引用它们来支撑观点**（像在讲述自己了解的知识），引用时在句末标注序号：

${t.map((n,i)=>`[${i+1}] 《${n.title}》：${n.text}`).join(`

`)}

### 使用准则
1. 这些是你学过的知识——引用时自然融入表达，可带出处如「我之前看的一个科普视频讲到…（[1]）」
2. 资料中明确提到的内容可以自信地使用；资料未覆盖的部分按你本身的知识与判断继续
3. 严禁编造资料中不存在的具体数字、结论——宁可保守表述
4. 同一份资料正反双方都能用，但引用必须贴合当前论点，不硬凑`}async function D(t,e=4){const n=await m(t,e);return n.length===0?null:S(n)}export{j as a,S as b,I as c,$ as d,d as g,K as i,B as p,D as r,m as s};
