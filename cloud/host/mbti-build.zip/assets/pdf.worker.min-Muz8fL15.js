const e=""+new URL("pdf.worker.min-CHFwMXne.mjs",import.meta.url).href;export{e as default};
